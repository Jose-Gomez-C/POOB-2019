package Shapes;
import java.awt.*;

/**
 * Write a description of class Figura here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Figura
{
    protected int xPosition;
    protected int yPosition;
    protected String color;
    protected boolean isVisible;


    public void makeVisible(){
        isVisible = true;
        draw();
    } 
    
    public void makeInvisible(){
        erase();
        isVisible = false;
    }
    
    public void moveRight(){
        moveHorizontal(20);
    }
    
    public void moveLeft(){
        moveHorizontal(-20);
    }
    
    public void moveUp(){
        moveVertical(-20);
    }
    
    public void moveDown(){
        moveVertical(20);
    }
    
    public void moveHorizontal(int distance){
        erase();
        xPosition += distance;
        draw();
    }
    
    public void moveVertical(int distance){
        erase();
        yPosition += distance;
        draw();
    }
    
    public void slowMoveHorizontal(int distance){
        int delta;

        if(distance < 0) {
            delta = -1;
            distance = -distance;
        } else {
            delta = 1;
        }

        for(int i = 0; i < distance; i++){
            xPosition += delta;
            draw();
        }
    }
    
    public void slowMoveVertical(int distance){
        int delta;

        if(distance < 0) {
            delta = -1;
            distance = -distance;
        } else {
            delta = 1;
        }

        for(int i = 0; i < distance; i++){
            yPosition += delta;
            draw();
        }
    }
    
    public void changeColor(String newColor){
        color = newColor;
        draw();
    }
    
    protected void erase(){
        if(isVisible) {
            Canvas canvas = Canvas.getCanvas(300,300);
            canvas.erase(this);
        }
    }
    
    public int GetxPosition(){
        return xPosition;
    }
    
    public int GetyPosition(){
        return yPosition;
    }
    
    public void setCambiarxy(int x, int y){
        erase();
        yPosition = y;
        xPosition = x;
        draw();     
    }
    
    protected void draw(){}
}
