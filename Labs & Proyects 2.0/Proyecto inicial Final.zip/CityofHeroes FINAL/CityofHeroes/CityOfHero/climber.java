package CityOfHero;
import java.util.ArrayList;
import java.util.Collections;
import javax.swing.JOptionPane;
import java.lang.Double;
import java.util.Hashtable;
import Shapes.*;

/**
 * Write a description of class climber here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class climber extends Heroe{
    Circle diferente;
    public climber(String color, int x,int y, int strength, int ancho){
        super(color,x,y,strength,ancho);
        diferente= new Circle();
        diferente.moveVertical(y-26);
        diferente.moveHorizontal(x-20+(ancho/2)+3);
        diferente.changeSize(10);
        if(color=="black"){
            diferente.changeColor("white");
        }else{
            diferente.changeColor("black");
        }
    }
    public void makeVisible(){
        super.makeVisible();
        diferente.makeVisible();
    }
    public void makeInvisible(){
        super.makeInvisible();
        diferente.makeInvisible();
    }
    public void changexy(int x,int y){
        super.changexy(x,y);
        diferente.setCambiarxy(x,y);
    }
    public void golpeEdificio(String color,int x,Rectangle calle,Hashtable<String,Heroe> Heroes,Hashtable<Integer, Edificio> Edificios,int altura,int[]ejex,ArrayList<String> muertos){
        if (calle.GetyPosition()-10>Heroes.get(color).yPosition()&& Heroes.get(color).yPosition()>0){
            if(Heroes.get(color).yPosition()-10>Edificios.get(x).yPosition()){
                while(Edificios.get(x).yPosition()-10<yPosition()){
                    changexy(xPosition(),yPosition()-3);
                }
                changexy(Edificios.get(x).xPosition()+Edificios.get(x).getAncho()/2,yPosition());
                super.pelea(x, color, Heroes,Edificios, muertos, calle);
            }else{
                changexy(Edificios.get(x).xPosition()+Edificios.get(x).getAncho()/2,yPosition());
                super.pelea(x, color, Heroes,Edificios, muertos, calle);
            }
        }else{
            muertos.add(color);
            super.muerto(calle,x);
        }
    }
}
