package CityOfHero;
import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import javax.swing.JOptionPane;
/**
 * The test class Aceptacion.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class Aceptacion
{
    private CityOfHeroes t1;
    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp(){
        
    }
    @Test
    public void AceptacionCity(){
        t1=new CityOfHeroes(1500,900);
        t1.makeVisible();
        int opcion= JOptionPane.showConfirmDialog(null,"¿La ciudad esta correcta?");
        assertTrue(opcion==0);
    }
    @Test
    public void AceptacionEdificios(){
        t1=new CityOfHeroes(1500,900);
        t1.addBuilding(0,100,100,15);
        t1.addBuilding(100,100,100,15);
        t1.addBuilding(200,100,100,15);
        t1.addBuilding(300,100,100,15);
        t1.addBuilding(400,100,100,15);
        t1.addBuilding(500,100,100,15);
        t1.addBuilding(600,100,100,15);
        t1.addBuilding(700,100,100,15);
        t1.addBuilding(800,100,100,15);
        t1.addBuilding(900,100,100,15);
        t1.addBuilding(1000,100,100,15);
        t1.addBuilding(1100,100,100,15);
        t1.addBuilding(1200,100,100,15);
        t1.addBuilding(1300,100,100,15);
        t1.addBuilding(1400,100,100,15);
        t1.makeVisible();
        int opcion= JOptionPane.showConfirmDialog(null,"¿Los edificios se ven bien?");
        assertTrue(opcion==0);
    }
    @Test
    public void AceptacionHeroes(){
        t1=new CityOfHeroes(1500,900);
        t1.addBuilding(0,100,100,15);
        t1.addBuilding(100,100,100,15);
        t1.addBuilding(200,100,100,15);
        t1.addBuilding(300,100,100,15);
        t1.addBuilding(400,100,100,15);
        t1.addBuilding(500,100,100,15);
        t1.addBuilding(600,100,100,15);
        t1.addBuilding(700,100,100,15);
        t1.addBuilding(800,100,100,15);
        t1.addBuilding(900,100,100,15);
        t1.addBuilding(1000,100,100,15);
        t1.addBuilding(1100,100,100,15);
        t1.addBuilding(1200,100,100,15);
        t1.addBuilding(1300,100,100,15);
        t1.addBuilding(1400,100,100,15);
        t1.addHeroe("black",1,15);
        t1.addHeroe("red",2,15);
        t1.addHeroe("green",3,15);
        t1.addHeroe("blue",4,15);
        t1.addHeroe("orange",5,15);
        t1.addHeroe("pink",6,15);
        t1.addHeroe("yellow",7,15);
        t1.addHeroe("magenta",8,15);
        t1.addHeroe("white",9,15);
        t1.addHeroe("gray",10,15);
        t1.makeVisible();
        int opcion= JOptionPane.showConfirmDialog(null,"¿Los Heroes se ven bien?");
        assertTrue(opcion==0);
    }
    @Test
    public void AceptacionClimber(){
        t1=new CityOfHeroes(1500,900);
        t1.addBuilding(0,100,100,15);
        t1.addBuilding(100,100,100,15);
        t1.addHeroe("climber","green",1,35);
        t1.makeVisible();
        int opcion= JOptionPane.showConfirmDialog(null,"¿El heroe climber se ve bien?");
        assertTrue(opcion==0);
    }
    @Test
    public void AceptacionParatrooper(){
        t1=new CityOfHeroes(1500,900);
        t1.addBuilding(0,100,100,15);
        t1.addBuilding(100,100,100,15);
        t1.addHeroe("paratrooper","green",1,35);
        t1.makeVisible();
        int opcion= JOptionPane.showConfirmDialog(null,"¿El Heroe paratrooper se ven bien?");
        assertTrue(opcion==0);
    }
    @Test
    public void AceptacionCareful(){
        t1=new CityOfHeroes(1500,900);
        t1.addBuilding(0,100,100,15);
        t1.addBuilding(100,100,100,15);
        t1.addHeroe("careful","green",1,35);
        t1.makeVisible();
        int opcion= JOptionPane.showConfirmDialog(null,"¿El Heroe careful se ven bien?");
        assertTrue(opcion==0);
    }
    @Test
    public void AceptacionSuperHero(){
        t1=new CityOfHeroes(1500,900);
        t1.addBuilding(0,100,100,15);
        t1.addBuilding(100,100,100,15);
        t1.addHeroe("s","green",1,35);
        t1.makeVisible();
        int opcion= JOptionPane.showConfirmDialog(null,"¿El Heroe superhero se ven bien?");
        assertTrue(opcion==0);
    }
    @Test
    public void AceptacionJumpLento(){
        t1=new CityOfHeroes(1500,900);
        t1.addBuilding(0,100,100,15);
        t1.addBuilding(100,100,200,15);
        t1.addBuilding(300,100,450,15);
        t1.addBuilding(400,100,100,15);
        t1.addHeroe("black",1,15);
        t1.makeVisible();
        t1.jump("black",116,81,true);
        int opcion= JOptionPane.showConfirmDialog(null,"¿El salto lento esta correcto?");
        assertTrue(opcion==0);
    }
    @Test
    public void AceptacionJumprapido(){
        t1=new CityOfHeroes(1500,900);
        t1.addBuilding(0,100,100,15);
        t1.addBuilding(100,100,200,15);
        t1.addBuilding(300,100,450,15);
        t1.addBuilding(400,100,100,15);
        t1.addHeroe("black",1,15);
        t1.makeVisible();
        t1.jump("black",116,81,false);
        int opcion= JOptionPane.showConfirmDialog(null,"¿El El salto rapido esta correcto?");
        assertTrue(opcion==0);
    }
    @Test
    public void AceptacionJumpParatrooper(){
        t1=new CityOfHeroes(1500,900);
        t1.addBuilding(0,100,100,100);
        t1.addBuilding(300,300,300,300);
        t1.makeVisible();
        t1.addHeroe("paratrooper","red",1,45);
        t1.jump("red",150,75,true);
        int opcion= JOptionPane.showConfirmDialog(null,"¿EL salto del paratrooper esta bien?");
        assertTrue(opcion==0);
    }
    @Test
    public void AceptacionJumpClimber(){
        t1=new CityOfHeroes(1500,900);
        t1.addBuilding(0,100,100,100);
        t1.addBuilding(300,300,300,300);
        t1.addHeroe("climber","red",1,45);
        t1.makeVisible();
        t1.jump("red",58,58,true);
        int opcion= JOptionPane.showConfirmDialog(null,"¿EL salto del climber esta bien?");
        assertTrue(opcion==0);
    }
    @Test
    public void AceptacionJump(){
        t1=new CityOfHeroes(1500,900);
        t1.addBuilding(0,100,100,100);
        t1.addBuilding(300,300,300,300);
        t1.addHeroe("blue",1,45);
        t1.makeVisible();
        t1.jump("blue",58,58,true);
        int opcion= JOptionPane.showConfirmDialog(null,"¿EL heroe salto bien?");
        assertTrue(opcion==0);
    }
    @Test
    public void AceptacionJumpCareful(){
        t1=new CityOfHeroes(1500,900);
        t1.addBuilding(0,100,100,100);
        t1.addBuilding(300,300,300,300);
        t1.addHeroe("careful","red",1,45);
        t1.makeVisible();
        t1.jump("red",74,58,true);
        int opcion= JOptionPane.showConfirmDialog(null,"¿EL salto del careful esta bien?");
        assertTrue(opcion==0);
    }
    @Test 
    public void AceptacionMuerteDelHeroeporEdificio(){
        t1=new CityOfHeroes(1500,900);
        t1.addBuilding(0,100,100,15);
        t1.addBuilding(100,100,200,15);
        t1.addBuilding(300,100,450,15);
        t1.addBuilding(400,100,100,15);
        t1.addHeroe("black",1,15);
        t1.makeVisible();
        t1.jump("black",58,58,true);
        int opcion= JOptionPane.showConfirmDialog(null,"¿El Heroe llego sin daños?");
        assertTrue(opcion==0);
    }
    @Test 
    public void Aceptacionpelea(){
        t1=new CityOfHeroes(1500,900);
        t1.addBuilding(0,100,100,15);
        t1.addBuilding(100,100,200,15);
        t1.addBuilding(300,100,450,15);
        t1.addBuilding(400,100,100,15);
        t1.addHeroe("black",1,15);
        t1.addHeroe("green",4,35);
        t1.makeVisible();
        t1.jump("black");
        JOptionPane.showMessageDialog(null,"La vida del heroe verde despues de la pelea es"+t1.strength("green"));
        int opcion= JOptionPane.showConfirmDialog(null,"¿La pelea fue correcta?");
        assertTrue(opcion==0);
    }
    @Test
    public void AceptacionPeleaNormalvsSuperHero(){
        t1=new CityOfHeroes(1500,900);
        t1.addBuilding(0,100,100,15);
        t1.addBuilding(100,100,200,15);
        t1.addBuilding(300,100,450,15);
        t1.addBuilding(400,100,100,15);
        t1.addHeroe("black",1,15);
        t1.addHeroe("s","green",4,35);
        t1.makeVisible();
        t1.jump("black");
        JOptionPane.showMessageDialog(null,"La vida del heroe verde despues de la pelea es"+t1.strength("green"));
        int opcion= JOptionPane.showConfirmDialog(null,"¿La pelea fue correcta?");
        assertTrue(opcion==0);
    }
    @Test
    public void AceptacionPeleaNormalvsClimber(){
        t1=new CityOfHeroes(1500,900);
        t1.addBuilding(0,100,100,15);
        t1.addBuilding(100,100,200,15);
        t1.addBuilding(300,100,450,15);
        t1.addBuilding(400,100,100,15);
        t1.addHeroe("black",1,15);
        t1.addHeroe("climber","green",4,35);
        t1.makeVisible();
        t1.jump("black");
        JOptionPane.showMessageDialog(null,"La vida del heroe verde despues de la pelea es"+t1.strength("green"));
        int opcion= JOptionPane.showConfirmDialog(null,"¿La pelea fue correcta?");
        assertTrue(opcion==0);
    }
    @Test
    public void AceptacionPeleaNormalvsCareful(){
        t1=new CityOfHeroes(1500,900);
        t1.addBuilding(0,100,100,15);
        t1.addBuilding(100,100,200,15);
        t1.addBuilding(300,100,450,15);
        t1.addBuilding(400,100,100,15);
        t1.addHeroe("black",1,15);
        t1.addHeroe("careful","green",4,35);
        t1.makeVisible();
        t1.jump("black");
        JOptionPane.showMessageDialog(null,"La vida del heroe verde despues de la pelea es"+t1.strength("green"));
        int opcion= JOptionPane.showConfirmDialog(null,"¿La pelea fue correcta?");
        assertTrue(opcion==0);
    }
    @Test
    public void AceptacionPeleaNormalvsParatrooper(){
        t1=new CityOfHeroes(1500,900);
        t1.addBuilding(0,100,100,15);
        t1.addBuilding(100,100,200,15);
        t1.addBuilding(300,100,450,15);
        t1.addBuilding(400,100,100,15);
        t1.addHeroe("black",1,15);
        t1.addHeroe("paratrooper","green",4,35);
        t1.makeVisible();
        t1.jump("black");
        JOptionPane.showMessageDialog(null,"La vida del heroe verde despues de la pelea es"+t1.strength("green"));
        int opcion= JOptionPane.showConfirmDialog(null,"¿La pelea fue correcta?");
        assertTrue(opcion==0);
    }
    @Test
    public void AceptacionPeleaParatroopervsNormal(){
        t1=new CityOfHeroes(1500,900);
        t1.addBuilding(0,100,100,15);
        t1.addBuilding(600,100,100,15);
        t1.addHeroe("black",2,15);
        t1.addHeroe("paratrooper","green",1,35);
        t1.makeVisible();
        t1.jump("green");
        JOptionPane.showMessageDialog(null,"La vida del heroe verde despues de la pelea es "+t1.strength("green"));
        int opcion= JOptionPane.showConfirmDialog(null,"¿La pelea fue correcta?");
        assertTrue(opcion==0);
    }
    @Test
    public void AceptacionHeroevsRadical(){
        t1=new CityOfHeroes(1500,900);
        t1.addBuilding(0,100,100,15);
        t1.addBuilding(100,100,200,15);
        t1.addBuilding("radical",300,100,450,15);
        t1.makeVisible();
        t1.addHeroe("black",1,15);
        t1.jump("black",80,75,true);
    }
}
