package CityOfHero;
import Shapes.*;

/**
 * Write a description of class Superhero here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Superhero extends Heroe{
    Circle ojod;
    Circle ojoi;
    Triangle casco;
    public Superhero(String color, int x,int y, int strength, int ancho){
        super(color,x,y,strength,ancho);
        ojod= new Circle();
        ojoi= new Circle();
        casco= new Triangle();
        ojod.moveVertical(y-20);
        ojod.moveHorizontal(x-18+(ancho/2)+3);
        ojod.changeSize(5);
        ojod.changeColor("white");
        ojoi.moveVertical(y-20);
        ojoi.moveHorizontal(x-24+(ancho/2)+3);
        ojoi.changeSize(5);
        ojoi.changeColor("white");
        casco.moveVertical(y-30);
        casco.moveHorizontal(x-85);
        casco.changeSize(10,10);
        casco.changeColor("black");
    }
    public void makeVisible(){
        super.makeVisible();
        ojod.makeVisible();
        ojoi.makeVisible();
        casco.makeVisible();
    }
    public void makeInvisible(){
        super.makeInvisible();
        ojod.makeInvisible();
        ojoi.makeInvisible();
        casco.makeInvisible();
    }
    public void changexy(int x,int y){
        super.changexy(x,y);
        ojod.setCambiarxy((int) (x),(int) (y));
        ojoi.setCambiarxy((int) (x)+5,(int) (y));
        casco.setCambiarxy((int) (x)+5,(int) (y)-10);
    }
    public void changestrength(int daño,Rectangle calle){
        
    }
}