package CityOfHero; 
/**
 * Write a description of interface Action here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */

public interface Action
{
    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y
     */
    void undo();
    
    void redo();
    
}

