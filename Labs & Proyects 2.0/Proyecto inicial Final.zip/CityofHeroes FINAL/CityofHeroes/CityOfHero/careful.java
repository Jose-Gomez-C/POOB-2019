package CityOfHero;
import java.util.ArrayList;
import java.util.Collections;
import javax.swing.JOptionPane;
import java.lang.Double;
import java.util.Hashtable;
import Shapes.*;
/**
 * Write a description of class Heroes here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class careful extends Heroe{
    Rectangle diferente;
    public careful(String color, int x,int y, int strength, int ancho){
        super(color,x,y,strength,ancho);
        diferente= new Rectangle();
        diferente.moveVertical(y-23);
        diferente.moveHorizontal(x-70+(ancho/2)+3);
        diferente.changeSize(10,4);
        if(color=="black"){
            diferente.changeColor("white");
        }else{
            diferente.changeColor("black");
        }
        }
    public void makeVisible(){
        super.makeVisible();
        diferente.makeVisible();
    }
    public void makeInvisible(){
        super.makeInvisible();
        diferente.makeInvisible();
    }
    public void changexy(int x,int y){
        super.changexy(x,y);
        diferente.setCambiarxy((int) (x+3),(int) (y));
    }
    public void jump(int velocity, int angle, boolean slow, int calle,int[] ejex,int altura,boolean ok,int ancho,ArrayList<String> muertos,int[] llave,Hashtable<Integer, Edificio> Edificios,Hashtable<String,Heroe> Heroes,Rectangle callei){
        if (saltoseguro(velocity, angle, calle, ejex, altura, ancho, Edificios,llave)){
            super.jump(velocity,  angle, slow, calle, ejex, altura, ok, ancho, muertos, llave,Edificios,Heroes,callei);
        }
    }
}
