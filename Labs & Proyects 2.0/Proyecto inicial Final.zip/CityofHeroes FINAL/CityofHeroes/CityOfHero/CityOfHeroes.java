package CityOfHero; 
import java.util.ArrayList;
import java.util.Collections;
import java.util.Hashtable;
import javax.swing.JOptionPane;
import java.lang.Math;
import java.util.Stack;
import Shapes.*;
/**
 * .
 *
 * @authors jose Luis Gomez C, Nikolai Bermudez
 * Esta clase permite crear edificios y heroes.
 * 
 */
public class CityOfHeroes
{
    private int ancho;
    private int c;
    private int[] ejex;
    private int[] aux;
    private int altura, anchura;
    
    
    private ArrayList<Integer> posx;
    private ArrayList<String> colores;
    private ArrayList<String> muertos;
    private Canvas canvas;


    private Hashtable<Integer, Edificio> Edificios;
    private Hashtable<String,Heroe> Heroes;
    
    private Rectangle calle;
    private Rectangle city;
    private Circle sol;
    
    private boolean visible=false;
    private boolean fin, veri;
    
    private Stack<Action> undoStack = new Stack();
    private Stack<Action> redoStack = new Stack();
    
    /**j
     * Constructor de objetos de la clase CityOfHeroes el cual pide una altura 
     * y ancho de la ciudad. 
     */
    public CityOfHeroes(int width,int height)
    {
        ejex = new int[width+10];
        aux = new int[width+10];
        
        altura = height;
        anchura = width+1;
        
        canvas = Canvas.getCanvas();
        
        city = new Rectangle();
        city.changeSize(height,width);
        city.changeColor("cyan");
        city.makeVisible();
        city.setCambiarxy(0,0);
        
        calle= new Rectangle();
        calle.changeSize(40,width);
        calle.moveHorizontal(-70);
        calle.moveVertical(height-55);
        calle.changeColor("gray");
        
        sol = new Circle();
        sol.changeColor("yellow");
        
        c=0;
        posx= new ArrayList<Integer>();
        colores= new ArrayList<String>();
        muertos= new ArrayList<String>();
        Edificios =new Hashtable<Integer, Edificio>();
        Heroes = new Hashtable<String,Heroe>();
        fin=true;
    }
    public void eliminarEdificios(){
        int x = posx.get(Edificios.size()-1);
        Edificios.remove(x);
    }
    
    public void agregarEdificio(int x,int ancho,int alto,int dureza){
        Edificio edificio= new Edificio(x,ancho,alto,altura,anchura,dureza,c,this);
        Edificios.put(x,edificio);
    }
    
    public void agregarHeroe(String color, int ed, int fuerza, boolean ok, int x, int y, int ancho){
        Heroe heroe = new Heroe(color, x,y, fuerza,ancho);
    }
    
    public void undo(){
        Action action = undoStack.pop();
        action.undo();
        redoStack.push(action);
    }
    public void redo(){
        Action action = redoStack.pop();
        action.redo();
        undoStack.push(action);
    
    }
    /**
     * Metodo que añade un edificios, con las caracteristicas que el usuario nos de como:
     * posicion, anchura, altura y dureza; todos de tipo entero.
     */
    public void addBuilding(int x, int width, int height,int hardness)
    {  
        boolean ok = true;
        if (width<0 || height<0 || height>altura-150 || x+width>anchura){
            ok=false;
        }
        if (ok){
            for(int i=x;i<=x+width;++i){
                if (ejex[i] !=0)
                    ok=false;
            }
         }
        if (ok)
        {
           if (c>7){
               c = 0;
           }
           Edificio edificio;
           for (int i=x;i<x+width;++i){
                ejex[i]= height;
                aux[i] = x;
             }
           Edificios.put(x,edificio= new Edificio(x,width,height,altura,anchura,hardness,c,this));
           if(visible){
               edificio.makeVisible();
            }
           posx.add(x);
           Collections.sort(posx);
           c+=1;
           undoStack.push(new StaticAction(edificio,"crear",x,width,this,"edificio",height,hardness));
           
        }
        else
        {
            fin=false;
        }
        
    }
    public void addBuilding(String type,int x, int width, int height,int hardness){  
        boolean ok = true;
        int posdechoque=0;
        if (width<0 || height<0 || height>altura-150 || x+width>anchura){
            ok=false;
        }
        if (ok){
            for(int i=x;i<=x+width && ok;++i){
                if (ejex[i] !=0){
                    ok=false;
                    posdechoque=i;
                }
            }
         }
        if (ok){
           if (c>7){
               c = 0;
           }
           Edificio edificio;
           for (int i=x;i<x+width;++i){
                ejex[i]= height;
                aux[i] = x;
             }
           if (type=="radical"){
                Edificios.put(x,edificio= new Radical(x,width,height,altura,anchura,hardness,c,this));
            }else if(type=="flexible"){
                Edificios.put(x,edificio= new Flexible(x,width,height,altura,anchura,hardness,c,this));
            }else{
                Edificios.put(x,edificio= new Edificio(x,width,height,altura,anchura,hardness,c,this));
            }
           if(visible){
               edificio.makeVisible();
            }
           posx.add(x);
           Collections.sort(posx);
           c+=1;
           undoStack.push(new StaticAction(edificio,"crear",x,width,this,"edificio",height,hardness));
        }else if (type.equals("flexible")){
            int xfin=0;
            int anchofin=-1;
            boolean posxFin=true;
            for(int i=posdechoque;i<=x+width&&posxFin;++i){
                if (ejex[i] ==0){
                    posxFin=false;
                    xfin=i;
                }
              }
            if (xfin!=0){
                boolean encontroelancho=true;
                for (int i = xfin;i<=x+width && xfin+width>i&& encontroelancho;++i){
                    if (ejex[i]!=0){
                        anchofin=i-xfin;
                        encontroelancho=false;
                    }else if(i+1==x+width){
                        anchofin=i-xfin;
                        encontroelancho=false;
                    }
                }
                Edificio edificio;
                Edificios.put(xfin,edificio= new Flexible(xfin,anchofin+1,height,altura,anchura,hardness,c,this));
                if(visible){
                    edificio.makeVisible();
                 }
                for (int i=xfin;i<xfin+anchofin;++i){
                    ejex[i]= height;
                    aux[i] = xfin;
                 }
                posx.add(xfin);
                Collections.sort(posx);
                c+=1;
                undoStack.push(new StaticAction(edificio,"crear",x,width,this,"edificio",height,hardness));
            }else{
                fin=false;
            }
        }else{
            fin=false;
        }
    }
    /**
     * Metodo que añade un heroe, con respecto a las caracteristicas que nos envie el usuario como:
     * color de tipo String
     * edificio donde el heroe inicia su aventura y su fuerza, de tipo entero.
     */
    public void addHeroe(String color, int hidingBuilding, int strength)
    {
       boolean ok= posx.size()>hidingBuilding-1 && posx.size()!=0 ;
       if (ok){
           Heroe heroe;
           int x = posx.get(hidingBuilding-1);
           int y = altura-45-Edificios.get(x).getAlto();
           colores.add(color);
           heroe = new Heroe(color,x,y,strength,Edificios.get(x).getAncho());
           if(visible){
               heroe.makeVisible();
            }
           Heroes.put(color,heroe);
           Edificios.get(x).setVisitante(heroe);
          undoStack.push(new StaticAction(heroe,"crear",this,"heroe",heroe.getColor(),hidingBuilding,strength,Edificios.get(x).getAncho(),y));
        }else{
           fin=false;
         }  
       }
    public void addHeroe(String type, String color, int hidingBuilding, int strength){
       boolean ok= posx.size()>hidingBuilding-1 && posx.size()!=0 ;
       if (ok){
           Heroe heroe;
           int x = posx.get(hidingBuilding-1);
           int y = altura-45-Edificios.get(x).getAlto();
           colores.add(color);
           Heroe hero;
           if (type=="careful"){
               hero = new careful (color,x,y,strength,Edificios.get(x).getAncho());
            }else if(type=="climber"){
               hero = new climber (color,x,y,strength,Edificios.get(x).getAncho());
            }else if(type=="paratrooper"){
               hero = new paratrooper (color,x,y,strength,Edificios.get(x).getAncho());
            }else{
               hero = new Superhero (color,x,y,strength,Edificios.get(x).getAncho());
            }
           if(visible){
               hero.makeVisible();
            }
           Heroes.put(color,hero); 
           Edificios.get(x).setVisitante(hero);
           undoStack.push(new StaticAction(hero,"crear",this,"heroe",hero.getColor(),hidingBuilding,strength,Edificios.get(x).getAncho(),y));
        }else{
           fin=false;
         } 
     }
    
    public void addHeroe(String color, int hidingBuilding, int strength, boolean veri)
    {
       boolean ok= posx.size()>hidingBuilding-1 && posx.size()!=0 ;
       int temp = hidingBuilding;
       if (ok){
           Heroe heroe;
           int x = posx.get(hidingBuilding-1);
           int y = altura-45-Edificios.get(x).getAlto();
           colores.add(color);
           heroe = new Heroe(color,x,y,strength,Edificios.get(x).getAncho());
           if(visible){
            heroe.makeVisible();
            
           Heroes.put(color,heroe);
           Edificios.get(x).setVisitante(heroe);
           
            if(veri == true){
                undoStack.push(new StaticAction(heroe,"crear",this,"heroe",heroe.getColor(),hidingBuilding,strength,Edificios.get(x).getAncho(),y));
           }
        }else{
           fin=false;
           }  
       }
    }
    /**
     * Metodo que elimina un edificio con respecto al orden visual del usuario
     */

    public void removeBuilding(int position){
        int x = posx.get(position-1);

        Edificios.get(x).makeInvisible();
        for (int i=x;i<x+Edificios.get(x).getAncho();++i){
                ejex[i]= 0;
        }
        Edificio temp = Edificios.get(x);
        Edificios.remove(x);
        undoStack.push(new StaticAction(temp,"eliminar",x,temp.getAncho(),this,"edificio",temp.getAlto(),temp.getHardness()));
    }
    /**
     * Este metodo remueve un heroe, el que el usuario indique con su color respectivo.
     */
    public void removeHero(String color){
      boolean ok=false;
      for(String i:colores){
          if (i==color){
              ok=true;
              break;
            }
        }
      if (colores.size()>0 && ok){
          Heroes.get(color).makeInvisible();
          quitarVisitante(color,aux[Heroes.get(color).xPosition()]);
          
          undoStack.push(new StaticAction(Heroes.get(color),"eliminar",this,"heroe",color));
       }else{
           fin=false;
         }
    }
     /**
     * Este metodo remueve un heroe, el que el usuario indique con su color respectivo.
     */
    public void removeHero(String color, boolean veri){
      boolean ok=false;
      for(String i:colores){
          if (i==color){
              ok=true;
              break;
            }
       }
      if (colores.size()>0 && ok){
          Heroes.get(color).makeInvisible();
          quitarVisitante(color,aux[Heroes.get(color).xPosition()]);
          if (veri == true){
          undoStack.push(new StaticAction(Heroes.get(color),"eliminar",this,"heroe",color));
          }
       }
      else{
           fin=false;
        }
    }
    public String[] deads(){
        String[] deads= new String[muertos.size()];
        return muertos.toArray(deads);
    }
    public void finish(){
        System.exit(0);
    }
    public void zoom(char z){
        if (z =='+' || z =='-'){
            canvas.acercar(z);
            if (z =='+'){
             undoStack.push(new zoomAction("acercarse",this));
            }else{
             undoStack.push(new zoomAction("alejarse",this));  
        }
       }
       else{
            fin=false;
        }
    }
    public void alternativeZoom(char z){
        if (z =='+' || z =='-'){
            canvas.acercar(z);
        }
    }
    /**
     * Este metodo genera el salto de un heroe, el usuario escoge cual heroe quiere que salte.
     */
    public void jump(String heroe, int velocity, int angle, boolean slow ){
      boolean ok=false;
      int posicionY = Heroes.get(heroe).yPosition();
      int posicionX = Heroes.get(heroe).xPosition();
      for(String i:colores){
          if (i==heroe){
              ok=true;
              break;
            }
        }
      if (colores.size()>0 && ok){
            if (velocity !=0 && angle != 0){
                Heroe hero=Heroes.get(heroe);
                hero.jump(velocity,angle,slow,calle.GetyPosition(),ejex,altura,ok,anchura,muertos,aux, Edificios,Heroes,calle);
                undoStack.push(new MovementAction(Heroes.get(heroe),Edificios.get(aux[Heroes.get(heroe).xPosition()]),"salto",posicionY,posicionX));
            }
       }
    }
    public void jump(String heroe,int building){
        int posicionY = Heroes.get(heroe).yPosition();
      int posicionX = Heroes.get(heroe).xPosition();
        int[] lista = jumpPlan(heroe,building);
        jump(heroe,lista[1],lista[0],true);
        undoStack.push(new MovementAction(Heroes.get(heroe),Edificios.get(aux[Heroes.get(heroe).xPosition()]),"salto",posicionY,posicionX));
    }
    public void jump(String heroe){
        boolean ok=true;
        for(int i=posx.size(); i>0 && ok;--i){
            int[]salto=jumpPlan(heroe,i);
            if(salto[0]!=0&&salto[1]!=0){
                jump(heroe,salto[1],salto[0],true);
                ok=false;
            }
        }
    }
    public int[] jumpPlan(String heroe,int building){
        int llave = posx.get(building-1);
        int llave2 = aux[Heroes.get(heroe).xPosition()];
        int Xmax =  llave - Heroes.get(heroe).xPosition();
        return Heroes.get(heroe).jumpPlan(heroe, building, llave, llave2, Xmax, Edificios, Heroes, aux, calle, ejex, altura, anchura, posx);
    }
    public int strength(String color){
        return Heroes.get(color).getstrength();
    }
    public void makeVisible(){
        canvas.setVisible(true);
        calle.makeVisible();
        sol.makeVisible();
        for(int i:posx){
            Edificios.get(i).makeVisible();
          }
        for(String i:colores){
            Heroes.get(i).makeVisible();
          }
        visible=true;
    }
    public boolean isSafejump(String heroe,int velocity,int angle){
        return Heroes.get(heroe).saltoseguro(velocity, angle,calle.GetyPosition(),ejex,altura, anchura, Edificios,aux);
    }
    
     public boolean isSafeJump(String hero,int building){
        int[] dates = jumpPlan(hero,building);
        return isSafejump(hero,dates[1],dates[0]);
    }
    public void makeInvisible(){
        canvas.setVisible(true);
        calle.makeInvisible();
        sol.makeInvisible();
        for(int i:posx){
            Edificios.get(i).makeInvisible();
         }
        for(String i:colores){
            Heroes.get(i).makeInvisible();
         }
        visible=false;
    }
    public boolean ok(){
        return fin;
    }
    private void quitarVisitante(String color,int x){
        Edificios.get(x).setVisitante(null);
     }
    public int[][][] city(){
        int [][][] city = new int[2][][];
        int [][] edifiosCity = new int [posx.size()][4];
        int [][] heroesCity = new int [colores.size()][2];
        int aux = 0, aux1 = 0;
        for (int x=0;x<posx.size();++x){
            Edificio tempo=Edificios.get(posx.get(x));
            System.out.println(x+"x");
            System.out.println(aux+"x");
            edifiosCity[x][aux] = posx.get(x);
            edifiosCity[x][aux+1] = tempo.getAncho();
            edifiosCity[x][aux+2] = tempo.getAlto();
            edifiosCity[x][aux+3] = tempo.getHardness();
            
        }
        for(int i=0;i<colores.size();++i){
            Heroe tempo = Heroes.get(colores.get(i));
            System.out.println(tempo.xPosition()+"hola");
            heroesCity[i][aux1] = tempo.xPosition();
            heroesCity[i][aux1+1] = tempo.getstrength();
        }
        city[0]=edifiosCity;
        city[1]=heroesCity;
        return city;
    }
    public void modificarEjeX(int x1, int x2, int n)
    {
        for(int i = x1; i<=x2;++i){
            ejex[i]=n;
        }
    }
    public ArrayList<Integer> getPosx(){
        return posx;
    }
    public boolean isDamaged(int position){
        return Edificios.get(posx.get(position-1)).getDañado();
    }
}