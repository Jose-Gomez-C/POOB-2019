package CityOfHero; 
/**
 * Write a description of class ZoomAction here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class zoomAction implements Action
{
    private String actionType;
    private CityOfHeroes cityOfHeroes;
    
    public zoomAction(String actionType,CityOfHeroes cityOfHeroes){
        this.actionType = actionType;
        this.cityOfHeroes = cityOfHeroes;
    }
    
    /**
     * 
     *
     * @param  
     * @return  
     */
    public void undo()
    {
        if (actionType.equals("acercarse") ){
            cityOfHeroes.alternativeZoom('-');
        }else{
            cityOfHeroes.alternativeZoom('+');
        }
    }
    
    /**
     * 
     *
     * @param  
     * @return  
     */
    public void redo()
    {
        if (actionType.equals("acercarse") ){
            cityOfHeroes.alternativeZoom('+');
        }else{
            cityOfHeroes.alternativeZoom('-');
        }
    }
}
