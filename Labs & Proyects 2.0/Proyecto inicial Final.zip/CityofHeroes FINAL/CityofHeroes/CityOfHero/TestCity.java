package CityOfHero; 
import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
* The test class TestCity.
*
* @author  (your name)
* @version (a version number or a date)
*/
public class TestCity
{
    private CityOfHeroes t1, t2;
    
    /**
    * Sets up the test fixture.
    *
    * Called before every test case method.
    */
    @Before
    public void setUp(){
    t1=new CityOfHeroes(1500,900);
    }
    @Test
    public void DeberiaCrearEdificios(){
        t1.addBuilding(0,100,100,15);
        t1.addBuilding(100,100,100,15);
        t1.addBuilding(200,100,100,15);
        t1.addBuilding(300,100,100,15);
        t1.addBuilding(400,100,100,15);
        t1.addBuilding(500,100,100,15);
        t1.addBuilding(600,100,100,15);
        t1.addBuilding(700,100,100,15);
        t1.addBuilding(800,100,100,15);
        t1.addBuilding(900,100,100,15);
        t1.addBuilding(1000,100,100,15);
        t1.addBuilding(1100,100,100,15);
        t1.addBuilding(1200,100,100,15);
        t1.addBuilding(1300,100,100,15);
        t1.addBuilding(1400,100,100,15);
        assertTrue(t1.ok());
    }
    @Test
    public void Nodeberiacrearedificios(){
        t1.addBuilding(0,500,100,15);
        t1.addBuilding(250,100,100,15);
        assertFalse(t1.ok());
    }
    @Test
    public void Nodeberiacrearedificio(){
        t1.addBuilding(1500,500,100,15);
        assertFalse(t1.ok());
    }
    @Test
    public void DeberiacrearHeroes(){
        t1.addBuilding(0,100,100,15);
        t1.addBuilding(100,100,100,15);
        t1.addBuilding(200,100,100,15);
        t1.addBuilding(300,100,100,15);
        t1.addBuilding(400,100,100,15);
        t1.addBuilding(500,100,100,15);
        t1.addBuilding(600,100,100,15);
        t1.addBuilding(700,100,100,15);
        t1.addBuilding(800,100,100,15);
        t1.addBuilding(900,100,100,15);
        t1.addBuilding(1000,100,100,15);
        t1.addBuilding(1100,100,100,15);
        t1.addBuilding(1200,100,100,15);
        t1.addBuilding(1300,100,100,15);
        t1.addBuilding(1400,100,100,15);
        t1.addHeroe("Black",1,15);
        t1.addHeroe("Black",2,15);
        t1.addHeroe("Black",3,15);
        t1.addHeroe("Black",4,15);
        t1.addHeroe("Black",5,15);
        t1.addHeroe("Black",6,15);
        t1.addHeroe("Black",7,15);
        t1.addHeroe("Black",8,15);
        t1.addHeroe("Black",9,15);
        t1.addHeroe("Black",10,15);
        t1.addHeroe("Black",11,15);
        t1.addHeroe("Black",12,15);
        t1.addHeroe("Black",13,15);
        t1.addHeroe("Black",14,15);
        t1.addHeroe("Black",15,15);
        assertTrue(t1.ok());
    }
    @Test
    public void NodeberiacrearHeroe(){
        t1.addHeroe("Black",15,15);
        assertFalse(t1.ok());
    }
    @Test
    public void DeberiaBorrarEdificio(){
        t1.addBuilding(1400,100,100,15);
        t1.addBuilding(100,100,100,15);
        t1.removeBuilding(1);
        t1.removeBuilding(2);
        assertTrue(t1.ok());
    }
    //@Test
    public void NoDeberiaBorrarEdificio(){
        t1.addBuilding(0,100,100,15);
        t1.addHeroe("Black",1,15);
        t1.removeBuilding(1);
        assertFalse(t1.ok());
    }
    @Test
    public void DeberiaBorrarHeroe(){
        t1.addBuilding(0,100,100,15);
        t1.addHeroe("Black",1,15);
        t1.removeHero("Black");
        assertTrue(t1.ok());
    }
    //@Test
    public void NodeberiaBorrarHeroe(){
        t1.removeHero("Black");
        assertTrue(t1.ok());
    }
    @Test
    public void Debereiajumpplan(){
        t1.addBuilding(0,100,100,15);
        t1.addBuilding(100,100,200,15);
        t1.addBuilding(300,100,450,15);
        t1.addBuilding(400,100,100,15);
        t1.addHeroe("black",1,15);
        int[]lista=t1.jumpPlan("black",4);
        t1.jump("black",lista[1],lista[0],false);
        assertTrue(t1.ok()&&t1.city()[1][0][0]==450);
    }
    //@Test
    public void deberiasersaltoseguro(){
        t1.addBuilding(100,100,100,15);
        t1.addHeroe("blue",1,45);
        t1.addBuilding(400,100,5,15);
        assertTrue(t1.isSafejump("blue",167,87));
    }
    //@Test
    public void deberiaJumpPlan(){
        t1.addBuilding(0,100,100,100);
        t1.addHeroe("blue",1,45);
        t1.addBuilding(300,300,300,300);
        int[] list=t1.jumpPlan("blue",2);
        t1.jump("blue",list[1],list[0],true);
        assertTrue(t1.strength("blue")==15);
    }
    @Test
    public void Debereiajump(){
        t1.addBuilding(0,100,100,15);
        t1.addBuilding(100,100,200,15);
        t1.addBuilding(300,100,450,15);
        t1.addBuilding(400,100,100,15);
        t1.addHeroe("black",1,15);
        t1.jump("black");
        assertTrue(t1.strength("black")==15&&t1.city()[1][0][0]==450);
    }
    @Test
    public void deberiaUndo(){
        t1.addBuilding(0,100,100,100);
        t1.addBuilding(200,100,100,100);
        t1.addBuilding(400,100,100,100);
        t1.addHeroe("red",1,45);
        t1.removeHero("red");
        t1.addHeroe("blue",1,45);
        t1.jump("blue",3);
        t1.undo();
        t1.undo();
        t1.undo();
        t1.undo();
        t1.undo();
        t1.undo();
        t1.undo();
        assertTrue(t1.ok());
    }
    @Test
    public void deberiacareful(){
        t1.addBuilding(0,100,100,100);
        t1.addBuilding(300,300,300,300);
        t1.addHeroe("careful","red",1,45);
        t1.jump("red",74,58,true);
        assertTrue(t1.strength("red")==45);
    }
        @Test
    public void deberiaclimber(){
        t1.addBuilding(0,100,100,100);
        t1.addBuilding(300,300,300,300);
        t1.addHeroe("climber","red",1,45);
        t1.jump("red",74,58,true);
        assertTrue(t1.strength("red")==45);
    }
    @Test
    public void deberiaparatrooper(){
        t1.addBuilding(0,100,100,100);
        t1.addBuilding(300,300,300,300);
        t1.addHeroe("paratrooper","red",1,45);
        t1.jump("red",150,75,true);
        assertTrue(t1.strength("red")==45);
    }
    @Test
    public void deberiapelearparatroopermorir(){
        t1.addBuilding(0,100,100,100);
        t1.addBuilding(600,300,300,300);
        t1.addHeroe("paratrooper","red",1,45);
        t1.jump("red",125,80,true);
        assertTrue(t1.strength("red")==0);
    }
    @Test
    public void deberiapelearclimbervsnormal(){
        t1.addBuilding(0,100,100,100);
        t1.addBuilding(300,300,300,300);
        t1.addHeroe("climber","blue",1,45);
        t1.addHeroe("green",2,55);
        t1.jump("blue",58,58,true);
        String[] muertos=t1.deads();
        assertTrue(muertos[0]=="blue"&& t1.strength("green")==55-45);
    }
    @Test
    public void deberiapelearclimbervsnormalp(){
        t1.addBuilding(0,100,100,100);
        t1.addBuilding(300,300,300,300);
        t1.addHeroe("climber","blue",1,45);
        t1.addHeroe("green",2,35);
        t1.jump("blue",58,58,true);
        String[] muertos=t1.deads();
        assertTrue(muertos[0]=="green");
    }
    @Test
    public void deberiasuperhero(){
        t1.addBuilding(0,100,100,100);
        t1.addBuilding(300,300,300,300);
        t1.addHeroe("superhero","red",1,45);
        t1.jump("red",58,58,true);
        assertTrue(t1.strength("red")==45);
    }
    @Test
    public void deberiaRadical(){
        t1.addBuilding(0,100,100,100);
        t1.addBuilding("radical",300,300,300,300);
        t1.addHeroe("superhero","red",1,45);
        t1.jump("red",58,58,true);
    }
    @Test
    public void DeberiaFlexible(){
        t1.addBuilding(0,100,100,100);
        t1.addBuilding(200,100,100,100);
        t1.makeVisible();
        t1.addBuilding("flexible",50,300,300,300);
        t1.ok();
    }
    @Test
    public void DeberiaFlexibleDanoHeroe(){
        t1.addBuilding(0,100,100,100);
        t1.addBuilding(200,100,100,100);
        t1.addBuilding("flexible",50,300,300,300);
        t1.addHeroe("red",1,45);
        t1.jump("red",58,58,true);
        assertTrue(t1.strength("red")==45);
    }
    @Test
    public void segunJMNoDeberiaRealizarSalto(){
        CityOfHeroes cof = new CityOfHeroes(500,500);
        cof.addBuilding("flexible",0,80,120,90);
        assertTrue(cof.ok());
        cof.addBuilding("flexible",150,150,320,60);
        assertTrue(cof.ok());
        cof.addHeroe("careful","white",1,90);
        assertTrue(cof.ok());
        cof.jump("white",45,45,false);
        assertFalse(cof.ok());
    }
    
}