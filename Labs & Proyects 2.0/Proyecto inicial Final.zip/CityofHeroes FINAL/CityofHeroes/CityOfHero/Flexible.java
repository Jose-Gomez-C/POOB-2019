package CityOfHero;
import Shapes.*;

/**
 * Write a description of class Flexible here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Flexible  extends Edificio {
    Rectangle diferente;
    /**
     * Constructor for objects of class Flexible
     */
    public Flexible(int x,int width,int height, int altura, int anchura,int hardness, int c,CityOfHeroes city){
        super( x, width, height, altura,  anchura, hardness,  c,city);
        diferente= new Rectangle();
        diferente.changeSize(height/10,width);
        diferente.changeColor(colores[c+1]);
        diferente.setCambiarxy(x,yPosition());
    }
    public void makeVisible(){
        super.makeVisible();
        diferente.makeVisible();
    }
    public void makeInvisible(){
        super.makeInvisible();
        diferente.makeInvisible();
    }
    public void changexy(int x,int y){
        super.changexy(x,y);
        diferente.setCambiarxy(x,y);
    }
    public int getHardness(){
        return 0;
    }
}
