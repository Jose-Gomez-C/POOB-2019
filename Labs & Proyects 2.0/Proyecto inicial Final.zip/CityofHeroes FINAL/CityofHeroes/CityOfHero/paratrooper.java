package CityOfHero;
import java.util.ArrayList;
import java.util.Collections;
import javax.swing.JOptionPane;
import java.lang.Double;
import java.util.Hashtable;
import Shapes.*;

/**
 * Write a description of class paratrooper here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class paratrooper  extends Heroe{
    Triangle diferente;
    public paratrooper(String color, int x,int y, int strength, int ancho){
        super(color,x,y,strength,ancho);
        diferente=new Triangle();
        diferente.moveVertical(y-20);
        diferente.moveHorizontal(x-140+(ancho/2)+3);
        diferente.changeSize(10,10);
        if(color=="black"){
            diferente.changeColor("white");
        }else{
            diferente.changeColor("black");
        }
     }
    public void makeVisible(){
        super.makeVisible();
        diferente.makeVisible();
     }
    public void changexy(int x,int y){
        super.changexy(x,y);
        diferente.setCambiarxy((int) (x+3),(int) (y));
     }
    public void golpeEdificio(String color,int x,Rectangle calle,Hashtable<String,Heroe> Heroes,Hashtable<Integer, Edificio> Edificios,int altura,int[]ejex,ArrayList<String> muertos){
        if (calle.GetyPosition()-10>Heroes.get(color).yPosition()&& Heroes.get(color).yPosition()>0){
            if(Heroes.get(color).yPosition()-10>Edificios.get(x).yPosition()){
                Edificios.get(x).cortar(altura-50-Heroes.get(color).yPosition(),Edificios.get(x).getAncho(),x,Heroes.get(color).yPosition()+10);
                super.newaltura(Edificios.get(x).getAlto(),x,Edificios.get(x).getAncho(),ejex);
                Edificios.get(x).puerta();
                Heroes.get(color).changexy(x+(Edificios.get(x).getAncho()/2),Heroes.get(color).yPosition());
                super.vida(x,color,Heroes,Edificios,calle);
                super.pelea(x, color, Heroes,Edificios, muertos, calle);
            }else{
                
                Heroes.get(color).changexy(x+(Edificios.get(x).getAncho()/2),Edificios.get(x).yPosition()-10);
                super.pelea(x, color, Heroes,Edificios, muertos, calle);
                }
        }else{
            if(Edificios.get(x).xPosition()<=Heroes.get(color).xPosition() && Edificios.get(x).xPosition()+Edificios.get(x).getAncho()>=Heroes.get(color).xPosition()){
                while(Edificios.get(x).yPosition()>Heroes.get(color).yPosition()){
                    changexy(Heroes.get(color).xPosition(),Heroes.get(color).yPosition()+3);
                }
                changexy(x+(Edificios.get(x).getAncho()/2),Heroes.get(color).yPosition()-10);
                super.pelea(x, color, Heroes,Edificios, muertos, calle);
            }else{
                while(calle.GetyPosition()>Heroes.get(color).yPosition()){
                    changexy(Heroes.get(color).xPosition(),Heroes.get(color).yPosition()+3);
                }
                muertos.add(color);
                muerto(calle,x);
            }
        }
    }
}
