package CityOfHero;
import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import java.util.Arrays;
    
public class ContestTest{
    public ContestTest(){
    }
    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp(){
    }
    @Test
    public void deberiaResolverCaso1(){
        CityOfHeroesContest ch = new CityOfHeroesContest();
        int [] configuracion = new int[] {4,1,100,55,1,1};
        int building [][] = new int [][]{{10,40,60,10}};
        String[][] solved = ch.solve(configuracion,building);
        String[][] correct= new String [][] {{"0","1","1","1"}};
        assertTrue(Arrays.deepEquals(solved,correct));
     }
    @Test
    public void deberiaResolverCaso2(){
        CityOfHeroesContest ch = new CityOfHeroesContest();
        int []configuracion = new int[] {4,4,100,55,1,1};
        int[][]building = new int [][] {{0,10,20,30},{10,20,30,40},{20,30,200,50},{30,40,50,60}};
        String[][] solved = ch.solve(configuracion,building);        
        String[][] correct= new String [][] {{"0","1","1","2"},{"1","1","1","2"},{"1","1","X","2"},{"2","2","2","3"}};        
        assertTrue(Arrays.deepEquals(solved,correct));
    }
    @Test
    public void noDeberiaSimularCaso2(){
        CityOfHeroesContest ch = new CityOfHeroesContest();
        int []configuracion = new int[] {4,4,100,55,1,1};
        int[][]building = new int [][] {{0,10,20,30},{10,20,30,40},{20,30,200,50},{30,40,50,60}};
        boolean simulate = ch.simulate(configuracion,building,1);        
        assertFalse(simulate);
    }
    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }
    }