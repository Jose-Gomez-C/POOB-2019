package CityOfHero;

/**
 * Write a description of class Movement here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MovementAction implements Action
{
    private Heroe heroe;
    private String actionType;
    private Edificio edificio;
    private int posy;
    private int posx;
    private int posicionXTemporal = 0;
    private int posicionYTemporal = 0;
    public MovementAction(Heroe heroe, Edificio edificio, String actionType, int posy, int posx){
        this.heroe = heroe;
        this.actionType = actionType;
        this.edificio = edificio;
        this.posy=posy;
        this.posx=posx;
    }
    /**
     * 
     *
     * @param  
     * @return  
     */
    public void undo()
    {
        System.out.println(posx + "posicionx undo");
       if(actionType.equals("salto")){
           edificio.setVisitante(null);
           heroe.changexy(posx,posy);
       }else{
           
       }
    }
    
    /**
     * 
     *
     * @param  
     * @return  
     */
    public void redo()
    {
              // if(actionType.equals("saltar")){
           //edificio.setVisitante(null);
           System.out.println(posx + "posicionx redo");
           heroe.changexy( posicionXTemporal, posicionXTemporal);
      // }

    }
    
    
}
