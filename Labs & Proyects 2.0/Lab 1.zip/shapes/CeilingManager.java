 /**
 * Librerias importadas de Java 
 * ArrayList para almacenar datos en memoria sin necesidad de declarar su tamaño.
 * Collections siendo todo aquello que se puede recorrer o iterar. Se puede saber su tamaño.
*/
import java.util.ArrayList;
import java.util.Collections;
/** 
 *
 * @ * @Jose Luis Gomez Camacho - Nikolai Bermudez Vega
 * 
 */
/**
 * 
 */
public class CeilingManager
{
    
    public Ceiling techo;
    int y = 100;
    ArrayList<Ceiling> techos;
    /**
     * Constructor 
     */
    public CeilingManager(int x)
    {
        //ArrayList<Integer> lista= new ArrayList<Integer>();
        //String color ="cyan";
        //techos= new ArrayList<Ceiling>();
        
        //for (int i=0;i<x;++i)
        //{
            //techo= new Ceiling();
            //techo.move(y,100);
            //techo.showCeiling();
            //y+=100;
            //techos.add(techo);
            
        }

        
    }

