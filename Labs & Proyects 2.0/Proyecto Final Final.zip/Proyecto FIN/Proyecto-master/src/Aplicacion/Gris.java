package Aplicacion;

public class Gris extends Bloque {
	
	public Gris(int posx,int posy) {
		super(posx,posy);
		imagen="BloqueGrisReflejo.gif";
		puntaje=0;
		estaVivo=false;
	}
	public void romperBloque(){
		
	}
}
