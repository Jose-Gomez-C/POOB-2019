package Aplicacion;

public class JugadorMimo {

	public JugadorMimo() {
		// TODO Auto-generated constructor stub
	}

}
