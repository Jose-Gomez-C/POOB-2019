package Aplicacion;

public class Negro extends Bloque {

	public Negro(int x, int y) {
		super(x, y);
		imagen="Negro.gif";
	}
	
}
