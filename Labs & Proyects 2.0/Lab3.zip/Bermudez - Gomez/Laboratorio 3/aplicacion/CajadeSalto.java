package aplicacion;
import java.awt.Color;
/**
 * Write a description of class Pesas here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
 
public class CajadeSalto implements EnSalon {
    private int posicionx,posiciony;
    private String nombre;
    private Color color;
    private Salon salon; 
    
     /**
     * Este metodo es el constructor de una CajadeSalto
     * @param salon, donde sera ubicado el objeto
     * @param nombre, como se llamara el objeto
     * @param posicionx, la posicion en x del objeto
     * @param posiciony, la posicion en y del objeto
     * @return
     */
    public CajadeSalto(Salon salon,String nombre,int posicionx, int posiciony){
        this.salon=salon;
        this.posicionx=posicionx;
        this.posiciony=posiciony;
        this.nombre=nombre;
        color=Color.BLACK;
        salon.adicione(this);
    } 
    
    /**
     * Este metodo el objeto CajadeSalto para y cambia su color.
     * unas acciones en especifico
     * @param 
     * @return
     */
    public void pare(){
        color = Color.RED;
    }
    
        /**
     * Este metodo el objeto CajadeSalto inicia y cambia de color.
     * unas acciones en especifico
     * @param 
     * @return
     */
    public void inicie(){
        color= Color.GREEN;
    }
    
     /**
     * Este metodo nos retorna el color de este objeto.
     * unas acciones en especifico
     * @param 
     * @return color de la caja.
     */
    public Color getColor(){
        return color;
    }
    
    public int getPosicionY(){
        return posiciony;
    }
    public int getPosicionX(){
        return posicionx;
    }
    
     /**
     * En este metodo retorna la forma del objeto(caja) 
     * @param
     * @return String
     */
    public String forma(){
        return EnSalon.FORMAS[2];
    }
}

