package aplicacion;

import java.awt.Color;

public class Deportista extends Persona implements EnSalon{
    

    private Salon salon;   
    protected String palabras;
    protected int paso;

     /**
     * Este metodo es el constructor de un Deportista
     * @param salon, donde sera ubicado el objeto
     * @param nombre, como se llamara el objeto
     * @param posicionx, la posicion en x del objeto
     * @param posiciony, la posicion en y del objeto
     * @return
     */
    public Deportista(Salon salon,String nombre,int posicionx, int posiciony){
        super(nombre,posicionx,posiciony);
        this.salon=salon;
        color=Color.BLACK;
        palabras="Soy"+nombre;
        salon.adicione(this);
        paso=0;
    }

    /**
     * Este metodo verifica si Deportista se puede mover
     * @param direccion, 
     * @return puede, un valor booleano.
     */
    protected boolean puedeMover(char direccion) {
        boolean puede=false;
        int posX = getPosicionX();
        int posY = getPosicionY();
        switch(direccion){
            case 'N' : puede = (posY+1 < salon.MAXIMO);
            break;
            case 'E' : puede = (posX+1 < salon.MAXIMO);
            break;
            case 'S' : puede = (posY-1 >= 0);
            break;
            case 'O': puede = (posX-1 >= 0);
            break; 
        } 
        return puede;
    }
    
     /**
     * Este metodo el objeto Deportista para.
     * @param
     * @return
     */
    public void pare(){
        muevaBrazo('I','B'); 
        muevaPierna('I','P');
        muevaBrazo('D','B'); 
        muevaPierna('D','P');       
        palabras="¡Uff!";
    }


     /**
     * Este metodo el objeto Deportista inicia sus movimentos
     * @param 
     * @return
     */
    public void inicie(){
        palabras="";
        paso++;
        if (getPosicionBrazo('I')==2 && getPosicionBrazo('D')==2){
            muevaBrazo('I','S'); 
            muevaPierna('I','S');
        } else if  (getPosicionBrazo('I')==FRENTE){
            muevaBrazo('I','S'); 
            muevaPierna('I','S');
        } else if (getPosicionBrazo('I')==ARRIBA){
            muevaBrazo('I','B'); 
            muevaPierna('I','B');
            muevaBrazo('I','B'); 
            muevaPierna('I','B');
            muevaBrazo('D','S'); 
            muevaPierna('D','S');
        }else if (getPosicionBrazo('D')==FRENTE){
            muevaBrazo('D','S'); 
            muevaPierna('D','S');
            muevaBrazo('D','S'); 
            muevaPierna('D','S');
            muevaBrazo('I','B'); 
            muevaPierna('I','B');
        }else if (getPosicionBrazo('D')==ARRIBA){
            muevaBrazo('D','B'); 
            muevaPierna('D','B');
            muevaBrazo('D','B'); 
            muevaPierna('D','B');
            muevaBrazo('I','S'); 
            muevaPierna('I','S');
        }       
        char direccion=( (paso % 2 == 0)  ? 'E':'O');
        if (puedeMover(direccion)){
            muevase(direccion);
        }
        System.out.println(getPosicionX()+"DEPPP");
    }

    /**
     * En este metodo retorna la forma del objeto(persona) 
     * @param
     * @return String
     */
    public String forma(){
        return EnSalon.FORMAS[0];
    }
    
     /**
     * En este metodo retorna un mensaje que da el objeto Deportista
     * @param
     * @return String
     */
    public String mensaje(){
        return  palabras;
    }

}

