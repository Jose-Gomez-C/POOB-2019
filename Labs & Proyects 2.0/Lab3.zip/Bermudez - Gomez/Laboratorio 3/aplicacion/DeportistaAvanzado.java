package aplicacion;

import java.awt.Color;
/**
 * Write a description of class DeportistaAvanzado here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class DeportistaAvanzado extends Deportista{
    /**
     * Constructor for objects of class DeportistaAvanzado
     */
    int parar=0;
    int puedenparar =5;
     /**
     * Este metodo es el constructor de un DeportistaAvanzado
     * @param salon, donde sera ubicado el objeto
     * @param nombre, como se llamara el objeto
     * @param posicionx, la posicion en x del objeto
     * @param posiciony, la posicion en y del objeto
     * @return
     */
    public DeportistaAvanzado(Salon salon,String nombre,int posicionx, int posiciony){
        super(salon,nombre,posicionx,posiciony);
        color=Color.ORANGE;
    }
    
        /**
     * En este metodo el objeto DeportistaAvanzado inicia sus respectivos
     * movimientos.
     * @param 
     * @return
     */
    public void inicie(){
        
        super.inicie();
        Paso=80;
        System.out.println(getPosicionX()+"ANAZAA");
    }
    
    /**
     * Este metodo el objeto DeportistaAvanzado para su movimiento y realiza
     * unas acciones en especifico
     * @param 
     * @return
     */
    public void pare(){
        if(puedenparar!=0){
            if(parar==1){
                super.pare();
                parar=0;
                --puedenparar;
            }else{
                ++parar;
            }
         }else{
             inicie();
         }
    }
    

    public void decida(){
        inicie();
    }
    
}
