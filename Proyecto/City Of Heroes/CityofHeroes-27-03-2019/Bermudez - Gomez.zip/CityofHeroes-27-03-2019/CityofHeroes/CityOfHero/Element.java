package CityOfHero; 
/**
 * Write a description of interface Element here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */

public interface Element
{
    void makeVisible();
    
    void makeInvisible();
    
    int yPosition();
    
    int xPosition();
    
}
