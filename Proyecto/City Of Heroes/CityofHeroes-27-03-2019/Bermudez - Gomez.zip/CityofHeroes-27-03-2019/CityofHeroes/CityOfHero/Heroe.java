package CityOfHero; 
import java.util.ArrayList;
import java.util.Collections;
import javax.swing.JOptionPane;
import java.lang.Double;
import java.util.Hashtable;
import Shapes.*;
/**
 * Write a description of class Heroes here.
 *
 * Esta clase crea un heroe
 */
public class Heroe implements Element{
    private Rectangle cuerpo; 
    private Rectangle fondovida;
    private Rectangle vida;
    private int fuerza;
    private String colorh;
    private boolean fin=true;
    
    /**
     * Este constructor es el encargado de hacer las caracteristicas de un heroe.
     */
   public Heroe (String color, int x,int y, int strength, int ancho){
       cuerpo= new Rectangle();
       cuerpo.changeSize(10,10);
       cuerpo.changeColor(color);
       cuerpo.moveVertical(y-20);
       cuerpo.moveHorizontal(x-70+(ancho/2));
       
       fondovida= new Rectangle();
       fondovida.changeSize(20,strength+20);
       fondovida.changeColor(color);
       fondovida.setCambiarxy(cuerpo.GetxPosition()-40,cuerpo.GetyPosition()-40);
       
       vida =  new Rectangle();
       vida.changeSize(10,strength);
       vida.changeColor("cyan");
       vida.setCambiarxy(cuerpo.GetxPosition()-30,cuerpo.GetyPosition()-35);
       
       fuerza=strength;
       
       colorh= color;
       
   }
   public void jump(int velocity, int angle, boolean slow, int calle,int[] ejex,int altura,boolean ok,int ancho,ArrayList<String> muertos,int[] llave,Hashtable<Integer, Edificio> Edificios,Hashtable<String,Heroe> Heroes,Rectangle callei){
       if (ok){
          int movex = this.cuerpo.GetxPosition();
          int movey = this.cuerpo.GetyPosition();
          double g = 9.81;
          double angulo = Math.toRadians(angle);
          double vuelot = (2*velocity*Math.sin(angulo))/g;
          double voX = velocity*Math.cos(angulo);
          double voY = velocity*Math.sin(angulo); 
          double t = 0.1;
          double x = this.cuerpo.GetxPosition();
          double y = this.cuerpo.GetyPosition();
          if (slow){
           while (this.cuerpo.GetyPosition()<calle && vueloSeguro(x,-y,ejex,altura) && this.cuerpo.GetyPosition()>0 && this.cuerpo.GetxPosition()>0 && this.cuerpo.GetxPosition()<ancho){
             x = (voX*t+movex);
             y = ((-4.9*(t*t))+(voY*t)-movey);
             changexy((int)(x),(int)(-y));
             t += 0.1;
            }
          }
          else{  
           while (this.cuerpo.GetyPosition()<calle && vueloSeguro(x,-y,ejex,altura)&& this.cuerpo.GetyPosition()>0 && this.cuerpo.GetxPosition()>0 && this.cuerpo.GetxPosition()<ancho){
             x = (voX*t+movex);
             y = ((-4.9*(t*t))+(voY*t)-movey);
             changexy((int)(x),(int)(-y));
             t += 0.1;
            }
          }
          cortaredificio(colorh,llave[xPosition()],callei,Heroes,Edificios, altura,ejex,muertos);
        }
       else{
            fin=false;
        }
   }
   public ArrayList<Integer> simulasalto(int velocity, int angle, int calle,int[] ejex,int altura,int ancho){
          int movex = this.cuerpo.GetxPosition();
          int movey = this.cuerpo.GetyPosition();
          double g = 9.81;
          double angulo = Math.toRadians(angle);
          double vuelot = (2*velocity*Math.sin(angulo))/g;
          double voX = velocity*Math.cos(angulo);
          double voY = velocity*Math.sin(angulo); 
          double t = 0.1;
          double x = this.cuerpo.GetxPosition();
          double y = this.cuerpo.GetyPosition();
          while (this.cuerpo.GetyPosition()<calle && vueloSeguro(x,-y,ejex,altura) && this.cuerpo.GetyPosition()>0 && this.cuerpo.GetxPosition()>0 && this.cuerpo.GetxPosition()<ancho){
             x = (voX*t+movex);
             y = ((-4.9*(t*t))+(voY*t)-movey);
             t += 0.1;
            }
          ArrayList<Integer> pos = new ArrayList<Integer>();
          pos.add((int)(-y));
          pos.add((int)(x));
          return pos;
    }
   private boolean vueloSeguro(double posX, double posY, int[] ejeX,int height){
       posX = Math.floor(posX);
       posY = Math.floor(posY);
       boolean ok = true;
       if(height -50-ejeX[(int) posX] <= (int) posY) {
           ok = false;
       }
       return ok;
   } 
   public void makeVisible(){
       this.cuerpo.makeVisible();
       this.fondovida.makeVisible();
       this.vida.makeVisible();
    }
   public void makeInvisible(){
       this.cuerpo.makeInvisible();
       this.fondovida.makeInvisible();
       this.vida.makeInvisible();
    }
   public int getstrength(){
       return this.fuerza;
    }
   public int yPosition(){
       return this.cuerpo.GetyPosition();
    }
   public int xPosition(){
       return this.cuerpo.GetxPosition();
    }
   public void changexy(int x,int y){
       this.cuerpo.setCambiarxy(x,y);
       this.fondovida.setCambiarxy(x-40,y-40);
       this.vida.setCambiarxy(x-30,y-35);
    }
   public String getColor(){
       return this.colorh;
    }
   public void changestrength(int daño){
       this.fuerza-=daño;
       while (fuerza!=vida.anchura()){
           this.vida.changeSize(vida.altura(),vida.anchura()-1);
       }
    }
   public boolean saltoseguro(int velocity, int angle, int calle,int[] ejex,int altura,int ancho,Hashtable<Integer, Edificio> Edificios,int[]aux){
       fin=false;
       ArrayList<Integer> list;
       list=this.simulasalto(velocity,angle, calle, ejex, altura, ancho);
       if (calle-10>list.get(0)&& list.get(0)>0){
           if(list.get(0)-10<Edificios.get(aux[list.get(1)]).yPosition()){
               fin=true;
            }
        }
       return fin;
    }
   public int[] jumpPlan(String heroe,int building,int llave,int llave2,int Xmax,Hashtable<Integer, Edificio> Edificios,Hashtable<String,Heroe> Heroes,int[]aux,Rectangle calle,int[]ejex,int altura,int anchura,ArrayList<Integer> posx){
        int[] fin = new int[2];
        double angulo;
        double v0;
        double div;
        if (Edificios.get(llave2).getAlto() < Edificios.get(llave).getAlto()){
            int Ymax = Edificios.get(llave).getAlto()-Edificios.get(aux[Heroes.get(heroe).xPosition()]).getAlto();
            div = (4*(double)(Ymax))/(2*(double)(Xmax));
            angulo= Math.atan(div);
            v0 = Math.sqrt((Ymax*2*(9.8))/Math.pow((Math.sin(angulo)),2));
        }else{
            int Ymax = Edificios.get(aux[Heroes.get(heroe).xPosition()]).getAlto();
            div = (4*(double)(Ymax))/(2*(double)(Xmax));
            angulo = Math.atan(div);
            v0 = Math.sqrt((Xmax*(9.8))/(Math.sin(2*angulo)));
        }
        int cont=0;
        int angulos=(int)((angulo*180)/Math.PI);
        while(angulos<90){
            if (isSafejump(heroe,(int)(v0),angulos,llave,Heroes,Edificios,calle,ejex,altura,anchura)){
                fin[0] =angulos ;
                fin[1] = (int)(v0);
                angulos=91;
            }else if(cont==0){
                int ymax=0;
                for(int i:posx){
                    ymax=Edificios.get(i).getAlto()>ymax?Edificios.get(i).getAlto():ymax;
                }
                ymax+=200;
                div=(4*(double)(ymax)/(2*(double)(Xmax)));
                angulo=Math.atan(div);
                v0=Math.sqrt((ymax*2*9.8)/Math.pow((Math.sin(angulo)),2));
                angulos=(int)((angulo*180)/Math.PI);
                cont+=1;
            }else{
                angulos+=1;
            }
        }
        return fin;
        }
   private boolean isSafejump(String heroe, int velocity, int angle,int edificio,Hashtable<String,Heroe> Heroes,Hashtable<Integer, Edificio> Edificios,Rectangle calle,int[]ejex,int altura,int anchura){ 
        boolean fin=false;
        ArrayList<Integer> list;
        list=Heroes.get(heroe).simulasalto(velocity,angle,calle.GetyPosition(),ejex,altura,anchura);
        if(calle.GetyPosition()-10>list.get(0) && list.get(0)>0){
            if (list.get(0)-10<Edificios.get(edificio).yPosition()&& list.get(1)>edificio && list.get(1)<edificio+Edificios.get(edificio).getAncho()){
                fin=true;
             }
        }
        return fin;
    }
   public void cortaredificio(String color,int x,Rectangle calle,Hashtable<String,Heroe> Heroes,Hashtable<Integer, Edificio> Edificios,int altura,int[]ejex,ArrayList<String> muertos){
        if (calle.GetyPosition()-10>Heroes.get(color).yPosition()&& Heroes.get(color).yPosition()>0){
            if(Heroes.get(color).yPosition()-10>Edificios.get(x).yPosition()){
                Heroes.get(color).changexy(x+(Edificios.get(x).getAncho()/2),Heroes.get(color).yPosition());
                vida(x,color,Heroes,Edificios);
                pelea(x, color, Heroes,Edificios, muertos, calle);
                newaltura(Edificios.get(x).getAlto(),x,Edificios.get(x).getAncho(),ejex);
                Edificios.get(x).puerta();
                Edificios.get(x).cortar(altura-50-Heroes.get(color).yPosition(),Edificios.get(x).getAncho(),x,Heroes.get(color).yPosition()+10);
            }else{
                Heroes.get(color).changexy(x+(Edificios.get(x).getAncho()/2),Edificios.get(x).yPosition()-10);
                pelea(x, color, Heroes,Edificios, muertos, calle);
                }
        }else{
            muertos.add(color);
            muerto(calle,x);
        }
     }
   public void newaltura(int alto,int x,int width,int[]ejex){
        for (int i=x;i<x+width;++i){
                ejex[i]= alto;
         }
    }
   public void vida(int x,String color,Hashtable<String,Heroe> Heroes,Hashtable<Integer, Edificio> Edificios){
        int vida = Heroes.get(color).getstrength();
        int daño = Edificios.get(x).getHardness();
        Heroes.get(color).changestrength(vida-daño);
    }    
   public void pelea(int x, String color,Hashtable<String,Heroe> Heroes,Hashtable<Integer, Edificio> Edificios,ArrayList<String> muertos,Rectangle calle){
        if (Edificios.get(x).getVisitante()!=null){
            if(Edificios.get(x).getVisitante().getstrength()>=Heroes.get(color).getstrength()){
                Edificios.get(x).getVisitante().makeInvisible();
                Edificios.get(x).getVisitante().makeVisible();
                Edificios.get(x).getVisitante().changestrength(Heroes.get(color).getstrength());
                Heroes.get(color).muerto(calle,x);
                muertos.add(color);
            }else{
                Heroes.get(color).makeInvisible();
                Heroes.get(color).makeVisible();
                Heroes.get(color).changestrength(Edificios.get(x).getVisitante() .getstrength());
                muertos.add(Edificios.get(x).getVisitante().getColor());
                Heroes.get(Edificios.get(x).getVisitante().getColor());
              }
         }else{
            Edificios.get(x).setVisitante(Heroes.get(color));
         }
    }
   public void muerto(Rectangle calle, int x){
       while(calle.GetyPosition()>yPosition()){
           changexy(xPosition(),yPosition()+2);
        }
      changestrength(fuerza);
    }
}

