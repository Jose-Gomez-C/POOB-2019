package CityOfHero;
import java.util.ArrayList;
import Shapes.*;

/**
 * Write a description of class Radical here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Radical extends Edificio {
    private Circle diferente; 
    /**
     * Constructor for objects of class Radical
     */
    
    public Radical(int x,int width,int height, int altura, int anchura,int hardness, int c,CityOfHeroes city){
        super( x, width, height, altura,  anchura, hardness,  c,city);
        diferente=new Circle();
        diferente.changeColor("cyan");
        diferente.changeSize(width/10);
        diferente.setCambiarxy(xPosition()+getAncho()/2,yPosition()+20);
    }
    public void makeVisible(){
        super.makeVisible();
        diferente.makeVisible();
    }
    public void makeInvisible(){
        super.makeInvisible();
        diferente.makeInvisible();
    }
    public void cortar(int newAltura,int newAncho,int x, int y){
        ArrayList<Integer> posx =ciudad.getPosx();
        int pos=0;
        for (int i=0;i<posx.size();++i){
            pos=posx.get(i)==x?i:0;
        }
        ciudad.removeBuilding(pos+1);
    }
}