package Aplicacion;

public class Pegajosa extends Poder{

	public Pegajosa(int posx, int posy) {
		super(posx, posy);
		imagen ="poderPegajosa.gif";
	}
	


}
