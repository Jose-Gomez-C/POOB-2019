package Aplicacion;

public class JugadorDestructor {

	public JugadorDestructor() {
		// TODO Auto-generated constructor stub
	}

}
